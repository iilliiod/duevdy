# 构建说明

该项目使用 `Gradle` 来简化构建过程和管理依赖项。

### Windows

> .\gradlew.bat run

### Mac/Linux

> ./gradlew run
