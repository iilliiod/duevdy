package duevdy;
import java.time.LocalDate;
public interface AppElement {
    public String getID();
    public String toString();
    public LocalDate getDate();
}
