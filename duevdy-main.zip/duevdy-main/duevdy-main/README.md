# A simple Note-Taking/To-Do App written in Java

<!-- ## Languages -->

<!-- - [English](docs/en/README.md) -->

> [中文](docs/zh/README.md)

# Build Instructions

The project uses `Gradle` to simplify the build process and manage dependencies.

### Windows

> .\gradlew.bat run

### Mac/Linux

> ./gradlew run
